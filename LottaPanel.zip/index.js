const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.get("/", (req, res) => {
  res.send("🌐 LottaPanel is running!");
});

app.listen(3000, () => {
  console.log("✅ LottaPanel backend running on http://localhost:3000");
});